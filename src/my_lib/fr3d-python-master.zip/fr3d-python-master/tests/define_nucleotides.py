# -*- coding: utf-8 -*-
"""
Created on Wed Nov 13 14:47:23 2013

@author: zirbel
"""

from unittest import skip
from unittest import TestCase

import numpy as np

from fr3d.data import Atom
from fr3d.data import Component
from fr3d.data import Structure

import tests.define_1S72_nucleotides


